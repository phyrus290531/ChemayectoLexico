# ═══════════════════════════════════════════════════════════════════
#  ANALIZADOR LÉXICO — MOTOR DE VIDEOJUEGOS BASADO EN TEXTO
#  Archivo: Juego.py
#  Descripción: Lee un archivo de instrucciones de misión (.txt),
#               tokeniza su contenido, clasifica cada token y
#               reporta errores léxicos descriptivos en consola.
# ═══════════════════════════════════════════════════════════════════

import sys
import os

# Forzar UTF-8 en la salida de consola (necesario en Windows)
if sys.stdout.encoding != 'utf-8':
    sys.stdout.reconfigure(encoding='utf-8')

# ─────────────────────────────────────────────────────────────────
#  CONSTANTES
# ─────────────────────────────────────────────────────────────────

# Lista fija de comandos válidos en MAYÚSCULAS
COMANDOS_VALIDOS = {
    "MOVER", "ATACAR", "USAR", "HABLAR",
    "TOMAR", "SOLTAR", "EXAMINAR", "ABRIR",
    "CERRAR", "EMPUJAR", "TIRAR", "MIRAR",
    "CORRER", "SALTAR", "NADAR", "ESCALAR",
    "LANZAR", "EQUIPAR", "GUARDAR", "CARGAR",
}

# Símbolos válidos de un solo carácter
SIMBOLOS = {
    '(': 'PARENTESIS_IZQ',
    ')': 'PARENTESIS_DER',
    ',': 'COMA',
    ';': 'PUNTO_Y_COMA',
    ':': 'DOS_PUNTOS',
}

NOMBRE_ARCHIVO = "quest.txt"


# ─────────────────────────────────────────────────────────────────
#  CLASE TOKEN
# ─────────────────────────────────────────────────────────────────

class Token:
    """Representa una unidad léxica encontrada en el código fuente."""

    def __init__(self, tipo, valor, linea, columna):
        self.tipo = tipo        # Categoría (COMANDO, IDENTIFICADOR, etc.)
        self.valor = valor      # Texto original
        self.linea = linea      # Línea (1-indexed)
        self.columna = columna  # Columna (1-indexed)

    def __repr__(self):
        return f"Token({self.tipo}, '{self.valor}', L{self.linea}:C{self.columna})"


# ─────────────────────────────────────────────────────────────────
#  CLASE ERROR LÉXICO
# ─────────────────────────────────────────────────────────────────

class ErrorLexico:
    """Representa un error léxico encontrado durante el análisis."""

    def __init__(self, caracter, linea, columna, mensaje):
        self.caracter = caracter  # Carácter o secuencia inválida
        self.linea = linea
        self.columna = columna
        self.mensaje = mensaje    # Descripción del error

    def __repr__(self):
        return f"Error('{self.caracter}', L{self.linea}:C{self.columna}, {self.mensaje})"


# ─────────────────────────────────────────────────────────────────
#  CLASE ANALIZADOR LÉXICO (LEXER)
# ─────────────────────────────────────────────────────────────────

class AnalizadorLexico:
    """Analizador léxico que recorre el texto carácter por carácter
    y produce una lista de tokens y una lista de errores."""

    def __init__(self, codigo):
        self.codigo = codigo
        self.pos = 0              # Posición actual en el texto
        self.linea = 1            # Línea actual (1-indexed)
        self.columna = 1         # Columna actual (1-indexed)
        self.tokens = []
        self.errores = []

    # ── Navegación ──────────────────────────────────────────────

    def caracter_actual(self):
        """Retorna el carácter actual o None si se llegó al final."""
        if self.pos < len(self.codigo):
            return self.codigo[self.pos]
        return None

    def avanzar(self):
        """Avanza al siguiente carácter, actualizando línea y columna."""
        if self.pos < len(self.codigo):
            if self.codigo[self.pos] == '\n':
                self.linea += 1
                self.columna = 1
            else:
                self.columna += 1
            self.pos += 1

    def peek(self):
        """Ve el siguiente carácter sin avanzar."""
        pos_siguiente = self.pos + 1
        if pos_siguiente < len(self.codigo):
            return self.codigo[pos_siguiente]
        return None

    # ── Lectores especializados ─────────────────────────────────

    def saltar_espacios(self):
        """Ignora espacios en blanco y tabulaciones."""
        while self.caracter_actual() is not None and self.caracter_actual() in ' \t\r':
            self.avanzar()

    def leer_palabra(self):
        """Lee una secuencia alfanumérica (letras, dígitos, guiones bajos)
        y la clasifica como COMANDO, IDENTIFICADOR o ERROR."""
        inicio_col = self.columna
        inicio_linea = self.linea
        palabra = ""

        while self.caracter_actual() is not None and (self.caracter_actual().isalnum() or self.caracter_actual() == '_'):
            palabra += self.caracter_actual()
            self.avanzar()

        # Clasificación de la palabra
        if palabra.isupper() and palabra.isalpha():
            # Palabra toda en mayúsculas → verificar si es comando válido
            if palabra in COMANDOS_VALIDOS:
                self.tokens.append(Token("COMANDO", palabra, inicio_linea, inicio_col))
            else:
                # Palabra en mayúsculas pero NO es un comando reconocido
                self.errores.append(ErrorLexico(
                    palabra, inicio_linea, inicio_col,
                    f"Comando '{palabra}' no reconocido. ¿Quisiste decir alguno de estos? {self._sugerir_comando(palabra)}"
                ))
        elif palabra[0].islower() or palabra[0] == '_':
            # Inicia con minúscula o guion bajo → identificador
            # Validar que solo contenga [a-z0-9_]
            if all(c.islower() or c.isdigit() or c == '_' for c in palabra):
                self.tokens.append(Token("IDENTIFICADOR", palabra, inicio_linea, inicio_col))
            else:
                # Mezcla de mayúsculas y minúsculas u otros caracteres
                self.errores.append(ErrorLexico(
                    palabra, inicio_linea, inicio_col,
                    f"Identificador '{palabra}' inválido: los identificadores deben contener solo minúsculas, dígitos y guiones bajos"
                ))
        elif palabra[0].isupper() and not palabra.isupper():
            # Inicia con mayúscula pero no es todo mayúsculas → error
            self.errores.append(ErrorLexico(
                palabra, inicio_linea, inicio_col,
                f"'{palabra}' no es válido: los comandos deben estar completamente en MAYÚSCULAS y los identificadores en minúsculas"
            ))
        elif palabra[0].isdigit():
            # Empieza con dígito pero tiene letras → error
            self.errores.append(ErrorLexico(
                palabra, inicio_linea, inicio_col,
                f"'{palabra}' no es válido: los identificadores no pueden iniciar con un número"
            ))
        else:
            self.errores.append(ErrorLexico(
                palabra, inicio_linea, inicio_col,
                f"Secuencia '{palabra}' no reconocida"
            ))

    def leer_numero(self):
        """Lee una secuencia de dígitos y crea un token NUMERO."""
        inicio_col = self.columna
        inicio_linea = self.linea
        numero = ""

        while self.caracter_actual() is not None and self.caracter_actual().isdigit():
            numero += self.caracter_actual()
            self.avanzar()

        # Si después del número viene una letra, es un error
        if self.caracter_actual() is not None and (self.caracter_actual().isalpha() or self.caracter_actual() == '_'):
            # Leer el resto como parte del error
            while self.caracter_actual() is not None and (self.caracter_actual().isalnum() or self.caracter_actual() == '_'):
                numero += self.caracter_actual()
                self.avanzar()
            self.errores.append(ErrorLexico(
                numero, inicio_linea, inicio_col,
                f"'{numero}' no es válido: los identificadores no pueden iniciar con un número"
            ))
        else:
            self.tokens.append(Token("NUMERO", numero, inicio_linea, inicio_col))

    def leer_comentario(self):
        """Lee desde '#' hasta el final de la línea y crea un token COMENTARIO."""
        inicio_col = self.columna
        inicio_linea = self.linea
        comentario = ""

        while self.caracter_actual() is not None and self.caracter_actual() != '\n':
            comentario += self.caracter_actual()
            self.avanzar()

        self.tokens.append(Token("COMENTARIO", comentario.strip(), inicio_linea, inicio_col))

    def leer_flecha(self):
        """Lee el símbolo '->' si el siguiente carácter es '>'."""
        inicio_col = self.columna
        inicio_linea = self.linea

        if self.peek() == '>':
            self.avanzar()  # consumir '-'
            self.avanzar()  # consumir '>'
            self.tokens.append(Token("FLECHA", "->", inicio_linea, inicio_col))
            return True
        return False

    # ── Sugerencia de comandos ──────────────────────────────────

    def _sugerir_comando(self, palabra):
        """Sugiere comandos similares basándose en distancia simple."""
        sugerencias = []
        for cmd in COMANDOS_VALIDOS:
            # Comparación básica: comparten al menos 50% de letras
            comunes = sum(1 for c in palabra if c in cmd)
            if comunes >= len(palabra) * 0.5:
                sugerencias.append(cmd)
        if sugerencias:
            return ", ".join(sorted(sugerencias)[:3])
        return "(ninguna sugerencia disponible)"

    # ── Método principal ────────────────────────────────────────

    def analizar(self):
        """Recorre todo el código fuente y genera tokens y errores."""
        while self.caracter_actual() is not None:
            char = self.caracter_actual()

            # Saltar espacios en blanco
            if char in ' \t\r':
                self.saltar_espacios()
                continue

            # Salto de línea
            if char == '\n':
                self.avanzar()
                continue

            # Comentarios
            if char == '#':
                self.leer_comentario()
                continue

            # Palabras (comandos o identificadores)
            if char.isalpha() or char == '_':
                self.leer_palabra()
                continue

            # Números
            if char.isdigit():
                self.leer_numero()
                continue

            # Flecha ->
            if char == '-':
                if self.leer_flecha():
                    continue
                else:
                    # '-' solo no es un símbolo válido
                    self.errores.append(ErrorLexico(
                        char, self.linea, self.columna,
                        f"Símbolo '-' no reconocido (¿falta '>' para formar '->'?)"
                    ))
                    self.avanzar()
                    continue

            # Símbolos válidos
            if char in SIMBOLOS:
                self.tokens.append(Token(SIMBOLOS[char], char, self.linea, self.columna))
                self.avanzar()
                continue

            # ─── Carácter no reconocido → ERROR LÉXICO ───
            self.errores.append(ErrorLexico(
                char, self.linea, self.columna,
                f"Símbolo '{char}' no reconocido en el lenguaje"
            ))
            self.avanzar()

        return self.tokens, self.errores


# ─────────────────────────────────────────────────────────────────
#  REPORTE EN CONSOLA
# ─────────────────────────────────────────────────────────────────

def imprimir_reporte(archivo, tokens, errores):
    """Imprime un reporte visual formateado en consola con la tabla
    de tokens encontrados y la lista de errores léxicos."""

    # ── Anchos de columna ───────────────────────────────────────
    col_no = 6
    col_valor = 28
    col_tipo = 16
    col_linea = 7
    col_col = 8
    ancho_total = col_no + col_valor + col_tipo + col_linea + col_col + 6  # 6 separadores |

    col_err_no = 6
    col_err_car = 12
    col_err_linea = 7
    col_err_col = 8
    col_err_desc = 45
    ancho_err = col_err_no + col_err_car + col_err_linea + col_err_col + col_err_desc + 6

    # ── Encabezado ──────────────────────────────────────────────
    print()
    print("╔" + "═" * (ancho_total - 2) + "╗")
    titulo = "ANALIZADOR LÉXICO — MOTOR DE VIDEOJUEGOS"
    print("║" + titulo.center(ancho_total - 2) + "║")
    print("╠" + "═" * (ancho_total - 2) + "╣")
    print("║" + f"  📂 Archivo analizado: {archivo}".ljust(ancho_total - 2) + "║")
    print("║" + f"  📊 Tokens encontrados: {len(tokens)}".ljust(ancho_total - 2) + "║")
    print("║" + f"  {'✅' if len(errores) == 0 else '❌'} Errores encontrados: {len(errores)}".ljust(ancho_total - 2) + "║")
    print("╚" + "═" * (ancho_total - 2) + "╝")

    # ── Tabla de Tokens ─────────────────────────────────────────
    print()
    print("  📋 TABLA DE TOKENS")
    print("  " + "┌" + "─" * col_no + "┬" + "─" * col_valor + "┬" + "─" * col_tipo + "┬" + "─" * col_linea + "┬" + "─" * col_col + "┐")
    print("  │" + "No.".center(col_no) + "│" + "Valor".center(col_valor) + "│" + "Tipo".center(col_tipo) + "│" + "Línea".center(col_linea) + "│" + "Col.".center(col_col) + "│")
    print("  " + "├" + "─" * col_no + "┼" + "─" * col_valor + "┼" + "─" * col_tipo + "┼" + "─" * col_linea + "┼" + "─" * col_col + "┤")

    for i, token in enumerate(tokens, 1):
        valor_display = token.valor
        if len(valor_display) > col_valor - 2:
            valor_display = valor_display[:col_valor - 5] + "..."
        print("  │" +
              str(i).center(col_no) + "│" +
              (" " + valor_display).ljust(col_valor) + "│" +
              (" " + token.tipo).ljust(col_tipo) + "│" +
              str(token.linea).center(col_linea) + "│" +
              str(token.columna).center(col_col) + "│")

    print("  " + "└" + "─" * col_no + "┴" + "─" * col_valor + "┴" + "─" * col_tipo + "┴" + "─" * col_linea + "┴" + "─" * col_col + "┘")

    # ── Tabla de Errores ────────────────────────────────────────
    if errores:
        print()
        print("  ⚠️  ERRORES LÉXICOS")
        print("  " + "┌" + "─" * col_err_no + "┬" + "─" * col_err_car + "┬" + "─" * col_err_linea + "┬" + "─" * col_err_col + "┬" + "─" * col_err_desc + "┐")
        print("  │" + "No.".center(col_err_no) + "│" + "Carácter".center(col_err_car) + "│" + "Línea".center(col_err_linea) + "│" + "Col.".center(col_err_col) + "│" + "Descripción".center(col_err_desc) + "│")
        print("  " + "├" + "─" * col_err_no + "┼" + "─" * col_err_car + "┼" + "─" * col_err_linea + "┼" + "─" * col_err_col + "┼" + "─" * col_err_desc + "┤")

        for i, error in enumerate(errores, 1):
            desc_display = error.mensaje
            if len(desc_display) > col_err_desc - 2:
                desc_display = desc_display[:col_err_desc - 5] + "..."
            car_display = error.caracter
            if len(car_display) > col_err_car - 2:
                car_display = car_display[:col_err_car - 5] + "..."
            print("  │" +
                  str(i).center(col_err_no) + "│" +
                  car_display.center(col_err_car) + "│" +
                  str(error.linea).center(col_err_linea) + "│" +
                  str(error.columna).center(col_err_col) + "│" +
                  (" " + desc_display).ljust(col_err_desc) + "│")

        print("  " + "└" + "─" * col_err_no + "┴" + "─" * col_err_car + "┴" + "─" * col_err_linea + "┴" + "─" * col_err_col + "┴" + "─" * col_err_desc + "┘")
    else:
        print()
        print("  ✅ No se encontraron errores léxicos. ¡El archivo es válido!")

    print()


# ─────────────────────────────────────────────────────────────────
#  PUNTO DE ENTRADA
# ─────────────────────────────────────────────────────────────────

def main():
    """Punto de entrada principal del analizador léxico."""

    # Determinar la ruta del archivo de misión
    # Se busca en el mismo directorio donde está Juego.py
    directorio_script = os.path.dirname(os.path.abspath(__file__))
    ruta_archivo = os.path.join(directorio_script, NOMBRE_ARCHIVO)

    # Verificar que el archivo existe
    if not os.path.exists(ruta_archivo):
        print(f"\n  ❌ Error: No se encontró el archivo '{NOMBRE_ARCHIVO}' en:")
        print(f"     {ruta_archivo}")
        print(f"\n  💡 Crea un archivo '{NOMBRE_ARCHIVO}' con instrucciones de misión.")
        print(f"     Ejemplo de contenido:")
        print(f"       MOVER(jugador, norte);")
        print(f"       ATACAR(enemigo1, espada_fuego);")
        print()
        sys.exit(1)

    # Leer el archivo
    try:
        with open(ruta_archivo, 'r', encoding='utf-8') as f:
            codigo = f.read()
    except Exception as e:
        print(f"\n  ❌ Error al leer el archivo: {e}")
        sys.exit(1)

    # Si el archivo está vacío
    if not codigo.strip():
        print(f"\n  ⚠️  El archivo '{NOMBRE_ARCHIVO}' está vacío.")
        print(f"     Agrega instrucciones de misión y vuelve a ejecutar.")
        print()
        sys.exit(0)

    # Ejecutar el analizador léxico
    lexer = AnalizadorLexico(codigo)
    tokens, errores = lexer.analizar()

    # Imprimir el reporte
    imprimir_reporte(NOMBRE_ARCHIVO, tokens, errores)


if __name__ == "__main__":
    main()
